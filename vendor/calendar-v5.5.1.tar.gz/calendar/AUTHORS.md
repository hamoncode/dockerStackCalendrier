<!--
  - SPDX-FileCopyrightText: 2024 Nextcloud GmbH and Nextcloud contributors
  - SPDX-License-Identifier: AGPL-3.0-or-later
-->
# Authors

- Anna Larch <anna.larch@gmx.net>
- Christoph Wurst <christoph@winzerhof-wurst.at>
- Georg Ehrke <oc.list@georgehrke.com>
- Grigory Vodyanov <scratchx@gmx.com>
- Hamza Mahjoubi <hamzamahjoubi221@gmail.com>
- Jakob Röhrl <jakob.roehrl@web.de>
- John Molakvoæ <skjnldsv@protonmail.com>
- Jonas Heinrich <heinrich@synyx.net>
- Julia Kirschenheuter <julia.kirschenheuter@nextcloud.com>
- Julius Härtl <jus@bitgrid.net>
- Mikhail Sazanov <m@sazanof.ru>
- Raghu Nayyar <hey@raghunayyar.com>
- René Gieling <github@dartcafe.de>
- Richard Steinmetz <richard@steinmetz.cloud>
- Thomas Citharel <tcit@tcit.fr>
- Thomas Müller <thomas.mueller@tmit.eu>
- Valdnet <47037905+Valdnet@users.noreply.github.com>
- Informatyka Boguslawski sp. z o.o. sp.k., https://www.ib.pl/
- Nextcloud GmbH
- ownCloud, Inc.
- Team Popcorn <teampopcornberlin@gmail.com>
